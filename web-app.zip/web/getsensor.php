<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));
	echo "Current sensor : ".$arr[1]." %<br>Installed sensor: ".$arr[4]." %";

?>