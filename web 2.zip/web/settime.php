<?php

	$time = strtotime($_GET['time']);

	$arr = explode('|', file_get_contents('ahihi.txt'));


	$content = $arr[0]."|".$arr[1]."|".$time."|".$arr[3]."|".$arr[4];

	echo $content;
	$fp = fopen("ahihi.txt","wb");
	fwrite($fp,$content);
	fclose($fp);

?>