<?php

	$brightness = $_GET['brightness'];

	$arr = explode('|', file_get_contents('ahihi.txt'));


	$content = $arr[0]."|".$arr[1]."|".$arr[2]."|".$brightness."|".$arr[4];

	echo $content;
	$fp = fopen("ahihi.txt","wb");
	fwrite($fp,$content);
	fclose($fp);

?>