<?php

	$sensor = $_GET['sensor'];

	$arr = explode('|', file_get_contents('ahihi.txt'));


	$content = $arr[0]."|".$arr[1]."|".$arr[2]."|".$arr[3]."|".$sensor;

	echo $content;
	$fp = fopen("ahihi.txt","wb");
	fwrite($fp,$content);
	fclose($fp);

?>