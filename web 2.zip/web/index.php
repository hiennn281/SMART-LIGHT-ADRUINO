<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<?php
	if(($_GET['username'] == "admin")&&($_GET['password'] == "password")){
		header("Location: http://smartlight-project.herokuapp.com/control.php");
	}
?>
<style type="text/css">
	.login100-pic.js-tilt {
	    margin-top: 35px;
	}
</style>
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="https://boygeniusreport.files.wordpress.com/2019/04/philips-hue-outdoor-smart-pathway-light.jpg?quality=98&strip=all&w=782" alt="IMG">
				</div>

				<form class="login100-form" method="GET">
					<span class="login100-form-title">
						Member Login
					</span>

					<div class="wrap-input100" >
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 ">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" onclick="checkPass();">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
						<span class="txt1">
							&ensp;
						</span>
						<a class="txt2" href="#">
							&ensp;
						</a>
					</div>

					<div class="text-center p-t-136">
						<a class="txt2" href="#">
							&ensp;
							
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	


</body>
</html>