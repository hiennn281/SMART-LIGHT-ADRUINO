<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));

	echo '<form>';
	echo '<div class="form-group">';				
    echo '<center><label for="formControlRange">Select light brightness</label></center>';                
    echo '<div class="col-md-1">';                    
    echo '<h2>0</h2>';                    
    echo '</div>';                      
    echo '<div class="col-md-10 offset-md-1">';                    
    echo '<input type="range" min=0 max=100 value="'.$arr[3].'" class="form-control-range" id="brightness" oninput="showBrightness(this.value)">';                    
    echo '</div>';                     
    echo '<div class="col-md-1 offset-md-11">';                    
    echo '<h2>100</h2>';                    
    echo '</div>';                      
    echo '</div>';                    
    echo '</form>';                  
    echo '<div class="col-md-12">';                
    echo '<center><h2 id="showBrightness">'.$arr[3].'</h2></center>';                
    echo '</div>';                
    echo '<center>';                     
    echo '<button type="button" class="btn btn-primary" onclick="setBrightness()">select</button>';                
    echo '</center>';                

?>