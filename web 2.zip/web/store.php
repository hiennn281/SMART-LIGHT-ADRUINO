<?php

  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  $led = $_GET['led'];
  $sensor = $_GET['sensor'];
  $time = $_GET['time'];
  $brightness = $_GET['brightness'];
  $currentsensor = $_GET['currentsensor'];

  $content = $led."|".$currentsensor."|".$time."|".$brightness."|".$sensor  ;

  echo $content;
  $fp = fopen("ahihi.txt","wb");
  fwrite($fp,$content);
  fclose($fp);





?>
