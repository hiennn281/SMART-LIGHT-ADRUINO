<?php

    $arr = explode('|', file_get_contents('ahihi.txt'));

    $led = $arr[0]
 ?>
                    <center>
                      <div class="btn-group" data-toggle="buttons">
                            <label class="btn btn-primary red <?php if($led==1){echo "active";} ?>">
                                <input type="radio" name="color" value="1" id="red"  autocomplete="off" <?php if($led==1){echo "checked";} ?> >
                                <span class="glyphicon glyphicon-ok"></span>
                            </label>

                            <label class="btn btn-primary orange <?php if($led==2){echo "active";} ?>">
                                <input type="radio" name="color" value="2" id="orange"  autocomplete="off" <?php if($led==2){echo "checked";} ?> >
                                <span class="glyphicon glyphicon-ok"></span>
                            </label>

                            <label class="btn btn-primary yellow <?php if($led==3){echo "active";} ?>">
                                <input type="radio" name="color" value="3" id="yellow" autocomplete="off" <?php if($led==3){echo "checked";} ?>  >
                                <span class="glyphicon glyphicon-ok"></span>
                            </label>

                            <label class="btn btn-primary green <?php if($led==4){echo "active";} ?>">
                                <input type="radio" name="color" value="4" id="green" autocomplete="off" <?php if($led==4){echo "checked";} ?>  >
                                <span class="glyphicon glyphicon-ok"></span>
                            </label>

                        <label class="btn btn-primary cyan <?php if($led==5){echo "active";} ?>">
                          <input type="radio" name="color" value="5" id="cyan" autocomplete="off" <?php if($led==5){echo "checked";} ?>  >
                          <span class="glyphicon glyphicon-ok"></span>
                        </label>

                        <label class="btn btn-primary blue <?php if($led==6){echo "active";} ?>">
                          <input type="radio" name="color" value="6" id="blue" autocomplete="off" <?php if($led==6){echo "checked";} ?>  >
                          <span class="glyphicon glyphicon-ok"></span>
                        </label>

                        <label class="btn btn-primary purple <?php if($led==7){echo "active";} ?>">
                          <input type="radio" name="color" value="7" id="purple" autocomplete="off" <?php if($led==7){echo "checked";} ?>  >
                          <span class="glyphicon glyphicon-ok"></span>
                        </label>

                        <label class="btn btn-primary pink <?php if($led==8){echo "active";} ?>">
                          <input type="radio" name="color" value="8" id="pink" autocomplete="off" <?php if($led==8){echo "checked";} ?>  >
                          <span class="glyphicon glyphicon-ok"></span>
                        </label>

                        </div>
                      <button type="button" class="btn btn-primary" onclick="setColor()">Change</button>
                    </center>