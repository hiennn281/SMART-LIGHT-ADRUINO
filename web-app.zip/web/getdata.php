<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));

	if(($arr[1] >= 0) && ($arr[1] < 10)){
		$arr[1] = '00'.$arr[1];
	}
	if(($arr[1] >= 10) && ($arr[1] < 100)){
		$arr[1] = '0'.$arr[1];
	}

	if(($arr[3] >= 0) && ($arr[3] < 10)){
		$arr[3] = '00'.$arr[3];
	}
	if(($arr[3] >= 10) && ($arr[3] < 100)){
		$arr[3] = '0'.$arr[3];
	}

	if(($arr[4] >= 0) && ($arr[4] < 10)){
		$arr[4] = '00'.$arr[4];
	}
	if(($arr[4] >= 10) && ($arr[4] < 100)){
		$arr[4] = '0'.$arr[4];
	}



	echo $content = $arr[0]."|".$arr[1]."|".$arr[2]."|".$arr[3]."|".$arr[4];


?>