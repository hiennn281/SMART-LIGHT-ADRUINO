<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));
	echo "<br>Sensor: ".$arr[4]." %";

?>