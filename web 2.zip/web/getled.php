<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));
	if($arr[0] == 1){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>';
	}elseif($arr[0] == 2){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:orange;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:orange;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:orange;font-size:130px;"></i>';
	}elseif($arr[0] == 3){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:yellow;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:yellow;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:yellow;font-size:130px;"></i>';
	}elseif($arr[0] == 4){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:green;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:green;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:green;font-size:130px;"></i>';
	}elseif($arr[0] == 5){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:cyan;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:cyan;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:cyan;font-size:130px;"></i>';
	}elseif($arr[0] == 6){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:blue;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:blue;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:blue;font-size:130px;"></i>';
	}elseif($arr[0] == 7){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:purple;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:purple;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:purple;font-size:130px;"></i>';
	}elseif($arr[0] == 8){
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:pink;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:pink;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:pink;font-size:130px;"></i>';
	}else{
		echo '
			<i class="fas fa-lightbulb pt-3" style="color:black;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:black;font-size:130px;"></i>
            <i class="fas fa-lightbulb pt-3" style="color:black;font-size:130px;"></i>';
	}

?>