<?php

	$arr = explode('|', file_get_contents('ahihi.txt'));
	echo "Birightness : ".$arr[3]." %<br>Alarm: 12:00 SA";

?>