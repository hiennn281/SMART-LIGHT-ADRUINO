<?php

	$led = $_GET['led'];

	$arr = explode('|', file_get_contents('ahihi.txt'));


	$content = $led."|".$arr[1]."|".$arr[2]."|".$arr[3]."|".$arr[4];

	echo $content;
	$fp = fopen("ahihi.txt","wb");
	fwrite($fp,$content);
	fclose($fp);

?>