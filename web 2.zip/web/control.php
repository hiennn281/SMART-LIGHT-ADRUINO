<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Smart Light</title>
  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css"  media="screen">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.min.css" rel="stylesheet">
  <style>
    div#nav-tabContent {
      background-color: #f0f0f0;
    }
    div#nav-switch {
        margin-top: 20px;
    }
    div#nav-brightness {
        margin-top: 20px;
    }
    div#nav-sensor {
        margin-top: 20px;
    }
    div#nav-alarm {
        margin-top: 20px;
    }
    .map-container iframe{
      left:0;
      top:0;
      height:100%;
      width:100%;
      position:absolute;
    }
    .col-md-12.card {
        padding: 0px !important;
    }
    .row.wow.fadeIn {
      margin: 0px !important;
    }
    a#nav-switch-tab {
      margin-left: -1px;
    }

    a#nav-alarm-tab {
        margin-right: -1px;
    }
    input[type="radio"] {
        opacity: 0;
    }

    label.btn.btn-primary.red {
        background: red !important;
    }
    label.btn.btn-primary.red.active {
        background: red !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.orange {
        background: orange !important;
    }
    label.btn.btn-primary.orange.active {
        background: orange !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.yellow {
        background: yellow !important;
    }
    label.btn.btn-primary.yellow.active {
        background: yellow !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.green {
        background: green !important;
    }
    label.btn.btn-primary.green.active {
        background: green !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.cyan {
        background: cyan !important;
    }
    label.btn.btn-primary.cyan.active {
        background: cyan !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.blue {
        background: blue !important;
    }
    label.btn.btn-primary.blue.active {
        background: blue !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.purple {
        background: purple !important;
    }
    label.btn.btn-primary.purple.active {
        background: purple !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    label.btn.btn-primary.pink {
        background: pink !important;
    }
    label.btn.btn-primary.pink.active {
        background: pink !important;
        border-top: 5px solid #000;
        border-bottom: 5px solid #000;
        padding-top: 5px;
        padding-bottom: 5px;
    }


  </style>
  <script type="text/javascript">
    function setBrightness() {
      $.ajax({
            url: "setbrightness.php?brightness=" + document.getElementById('brightness').value,
            success: function(response) {
                $.notify("Successful brightness setting!", "success");
            },
            error: function(xhr) {
                $.notify("Failed brightness setting!", "error");
            }
        });
      }


    function setTime() {
      $.ajax({
            url: "settime.php?time=" + document.getElementById('date').value,
            success: function(response) {
                $.notify("Successful time setting!", "success");
            },
            error: function(xhr) {
                $.notify("Failed time setting!", "error");
            }
        });
      }

    function setSensor() {
      $.ajax({
            url: "setsensor.php?sensor=" + document.getElementById('sensor').value,
            success: function(response) {
                $.notify("Successful sensor setting!", "success");
            },
            error: function(xhr) {
                $.notify("Failed sensor setting!", "error");
            }
        });
      }
    function setColor() {

      $.ajax({
          url: "setled.php?led=" + $("input[name='color']:checked").val(),
          success: function(response) {
              $.notify("Successful color setting!", "success");
          },
          error: function(xhr) {
              $.notify("Failed color setting!", "error");
          }
      });
    }

    function showBrightness(val){
      document.getElementById('showBrightness').innerHTML =val;
    }
    function showSensor(val){
      document.getElementById('showSensor').innerHTML =val;
    }
  </script>
</head>

<body class="container-fluid">
  <!--Main layout-->
  <main class="row">
    <div class="col-md-10 mt-3 offset-md-1">

      <!-- Heading -->
      <div class="card mb-4 wow">
        <!--Card content-->
        <div class="card-body d-sm-flex justify-content-between">
          <h4 class="mb-2 mb-sm-0 pt-1">
            <i class="fas fa-lightbulb"></i>
            <span>  SMART LIGHT</span>
            <i class="fas fa-lightbulb"></i>
          </h4>
        </div>

      </div>
      <!-- Heading -->
      <div class="row wow fadeIn">
  			<div class="col-md-6  offset-md-3 pt-2">

          <div class="card">
            <center>
            <h1 id="led-show">
              <i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>
              <i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>
              <i class="fas fa-lightbulb pt-3" style="color:red;font-size:130px;"></i>
            </h1>
            <div class="card-block">
                <h4 class="card-title"></h4>
                <div class="card-text mb-3">
                  
                </div>
            </div>
            <div class="card-footer">
                <span class="float-left">test</span>
                <span class="float-right">test</span>
                <span class="float-center">&ensp; <br> &ensp;</span>
            </div>
          </div>
        </div>
      </div>
      <br>
      <br>
      <div class="row wow fadeIn">
  			<div class="col-md-12 card">
  				<nav>
  					<div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
  						<a class="nav-item nav-link active" id="nav-switch-tab" data-toggle="tab" href="#nav-switch" role="tab" aria-controls="nav-switch" aria-selected="true">Switch</a>
  						<a class="nav-item nav-link" id="nav-brightness-tab" data-toggle="tab" href="#nav-brightness" role="tab" aria-controls="nav-brightness" aria-selected="false">Brightness</a>
              <a class="nav-item nav-link" id="nav-sensor-tab" data-toggle="tab" href="#nav-sensor" role="tab" aria-controls="nav-sensor" aria-selected="false">Sensor</a>
              <a class="nav-item nav-link" id="nav-alarm-tab" data-toggle="tab" href="#nav-alarm" role="tab" aria-controls="nav-alarm" aria-selected="false">Alarm</a>
  					</div>
  				</nav>
  				<div class="tab-content py-6 px-6 px-sm-0" id="nav-tabContent">
  					<div class="tab-pane fade show active" id="nav-switch" role="tabpanel" aria-labelledby="nav-switch-tab">
              <!--Grid column-->
              <div class="col-md-12 mb-4">
                <!--Card-->
                <div class="card">

                  <!--Card content-->
                  <div class="card-body" id="setled">
                    
                  </div>

                </div>
                <!--/.Card-->

              </div>
              <!--Grid column-->
            </div>
  					<div class="tab-pane fade" id="nav-brightness" role="tabpanel" aria-labelledby="nav-brightness-tab">
              <div class="col-md-12 mb-4">
                <div class="card">
                  <div class="card-body" id='setbrightness'>
                    <form>
                      <div class="form-group">
                        <center><label for="formControlRange">Select light brightness</label></center>
                        <div class="col-md-1">
                          <h2>0</h2>
                        </div>
                        <div class="col-md-10 offset-md-1">
                          <input type="range" min=0 max=10 class="form-control-range" id="brightness">
                        </div>
                        <div class="col-md-1 offset-md-11">
                          <h2>100</h2>
                        </div>
                      </div>
                    </form>
                    
                    <div class="col-md-12">
                          <center><h2>100</h2></center>
                    </div>
                    
                    <center>
                    <button type="button" class="btn btn-primary" onclick="setBrightness()">select</button>
                    </center>
                    
                  </div>
                </div>
              </div>
  					</div>
            <div class="tab-pane fade" id="nav-sensor" role="tabpanel" aria-labelledby="nav-sensor-tab">
              <div class="col-md-12 mb-4">
                <div class="card">
                  <div class="card-body" id='setsensor'>
                    <form>
                      <div class="form-group">
                        <center><label for="formControlRange">Sensor</label></center>
                        <div class="col-md-1">
                          <h2>0</h2>
                        </div>
                        <div class="col-md-10 offset-md-1">
                          <input type="range" min=0 max=10 class="form-control-range" id="sensor">
                        </div>
                        <div class="col-md-1 offset-md-11">
                          <h2>100</h2>
                        </div>
                      </div>
                    </form>
                    
                    <div class="col-md-12">
                          <center><h2>100</h2></center>
                    </div>
                    
                    <center>
                    <button type="button" class="btn btn-primary" onclick="setBrightness()">select</button>
                    </center>
                    
                  </div>
                </div>
              </div>
  					</div>
            <div class="tab-pane fade" id="nav-alarm" role="tabpanel" aria-labelledby="nav-alarm-tab">
              <div class="col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <br>
                    <form class="form-inline offset-md-4">
                      <center id="datatime">
                        <input class="form-control" type="datetime-local" id="date" name="trip-start" min="2019-01-07T00:00" max="2019-12-14T00:00" value="2019-12-07T00:00">
                      &ensp;&ensp;&ensp;
                      <button type="button" class="btn btn-primary" onclick="setTime()" >SET</button>
                      </center>
                    </form>
                  </div>
                </div>
              </div>
  					</div>
  				</div>

  			</div>
  		</div>



    </div>
  </main>
  <!--Main layout-->


  <!-- JQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/notify.js"></script>

  <script type="text/javascript">
    
        
    $(document).ready(function(){
      $('.float-left').load('getsensor.php');
      $('.float-right').load('getbrightness.php');
      $('#led-show').load('getled.php');
      $('#setbrightness').load('getsetbrightness.php');
      $('#setsensor').load('getsetsensor.php');
      $('#setled').load('getsetled.php');
      setInterval(function(){
      $('.float-left').load('getsensor.php');
      $('.float-right').load('getbrightness.php');
      $('#led-show').load('getled.php');
      }, 1000);
    });
  </script>


</body>

</html>
</html>
