<?php

    $arr = explode('|', file_get_contents('ahihi.txt'));

    echo '<form>';
    echo '<div class="form-group">';                
    echo '<center><label for="formControlRange">Select sensor sensitivity</label></center>';                
    echo '<div class="col-md-1">';                    
    echo '<h2>0</h2>';                    
    echo '</div>';                      
    echo '<div class="col-md-10 offset-md-1">';                    
    echo '<input type="range" min=0 max=100 value="'.$arr[4].'" class="form-control-range" id="sensor" oninput="showSensor(this.value)">';                    
    echo '</div>';                     
    echo '<div class="col-md-1 offset-md-11">';                    
    echo '<h2>100</h2>';                    
    echo '</div>';                      
    echo '</div>';                    
    echo '</form>';                  
    echo '<div class="col-md-12">';                
    echo '<center><h2 id="showSensor">'.$arr[4].'</h2></center>';                
    echo '</div>';                
    echo '<center>';                     
    echo '<button type="button" class="btn btn-primary" onclick="setSensor()">select</button>';                
    echo '</center>';                

?>